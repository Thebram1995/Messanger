#[macro_export]
macro_rules! create_proxy_post_endpoint {
    ($function_name:ident, $microservice:expr, $target_path:expr) => {
        pub async fn $function_name(
            axum::extract::State(state): axum::extract::State<crate::config::app_state::AppState>,
            headers: axum::http::HeaderMap,
            axum::Json(payload): axum::Json<serde_json::Value>,
        ) -> axum::response::Response {
            crate::proxy::proxy_engine::ProxyEngine::post(
                &state,
                headers,
                $microservice,
                $target_path,
                payload,
            )
            .await
        }
    };
}