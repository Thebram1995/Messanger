#[macro_export]
macro_rules! create_proxy_get_endpoint {
    ($function_name:ident, $microservice:expr, $target_path:expr) => {
        pub async fn $function_name(
            axum::extract::State(state): axum::extract::State<crate::config::app_state::AppState>,
            headers: axum::http::HeaderMap,
        ) -> axum::response::Response {
            crate::proxy::proxy_engine::ProxyEngine::get(
                &state,
                headers,
                $microservice,
                $target_path,
            )
            .await
        }
    };
}