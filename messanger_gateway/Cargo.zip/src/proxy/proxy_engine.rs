use axum::{
    http::{HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    Json,
};

use crate::proxy::service_registry::{
    Microservice,
    ServiceRegistry,
};

use reqwest::{Client, Method};
use serde_json::Value;

use crate::config::app_state::AppState;

pub struct ProxyEngine;

impl ProxyEngine {
    pub async fn get(
        state: &AppState,
        headers: HeaderMap,
        microservice: Microservice,
        target_path: &str,
    ) -> Response {
        Self::send_json(
            &state.client,
            Method::GET,
            ServiceRegistry::resolve(state, microservice, target_path),
            None,
            Self::extract_authorization(headers),
        )
        .await
    }

    pub async fn post(
        state: &AppState,
        headers: HeaderMap,
        microservice: Microservice,
        target_path: &str,
        body: Value,
    ) -> Response {
        Self::send_json(
            &state.client,
            Method::POST,
            ServiceRegistry::resolve(state, microservice, target_path),
            Some(body),
            Self::extract_authorization(headers),
        )
        .await
    }

    fn extract_authorization(headers: HeaderMap) -> Option<String> {
        headers
            .get("Authorization")
            .and_then(|value| value.to_str().ok())
            .map(|value| value.to_string())
    }

    async fn send_json(
        client: &Client,
        method: Method,
        url: String,
        body: Option<Value>,
        authorization: Option<String>,
    ) -> Response {
        let mut request = client.request(method, url);

        if let Some(token) = authorization {
            request = request.header("Authorization", token);
        }

        if let Some(json_body) = body {
            request = request.json(&json_body);
        }

        match request.send().await {
            Ok(response) => {
                let status = response.status();

                match response.json::<Value>().await {
                    Ok(json) => (
                        StatusCode::from_u16(status.as_u16())
                            .unwrap_or(StatusCode::INTERNAL_SERVER_ERROR),
                        Json(json),
                    )
                        .into_response(),

                    Err(_) => (
                        StatusCode::from_u16(status.as_u16())
                            .unwrap_or(StatusCode::INTERNAL_SERVER_ERROR),
                        "Error leyendo respuesta del microservicio",
                    )
                        .into_response(),
                }
            }

            Err(error) => (
                StatusCode::BAD_GATEWAY,
                format!("Error conectando con microservicio: {}", error),
            )
                .into_response(),
        }
    }
}