use crate::config::app_state::AppState;

#[derive(Debug, Clone, Copy)]
pub enum Microservice {
    Messenger,
}

pub struct ServiceRegistry;

impl ServiceRegistry {
    pub fn resolve(
        state: &AppState,
        microservice: Microservice,
        path: &str,
    ) -> String {
        match microservice {
            Microservice::Messenger => {
                format!("{}{}", state.config.messenger_ms_url, path)
            }
        }
    }
}