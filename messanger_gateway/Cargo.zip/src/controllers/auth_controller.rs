use crate::{
    create_proxy_post_endpoint,
    proxy::service_registry::Microservice,
};

create_proxy_post_endpoint!(
    login,
    Microservice::Messenger,
    "/auth/login"
);