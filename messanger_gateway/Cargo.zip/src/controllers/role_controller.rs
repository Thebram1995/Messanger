use crate::{
    create_proxy_get_endpoint,
    create_proxy_post_endpoint,
    proxy::service_registry::Microservice,
};

create_proxy_get_endpoint!(
    get_roles,
    Microservice::Messenger,
    "/roles"
);

create_proxy_post_endpoint!(
    create_role,
    Microservice::Messenger,
    "/roles"
);